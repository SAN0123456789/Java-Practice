package proj;

	class customException extends Exception  
	{  
		public customException() {
			System.out.println("Custom Exception"); 
		}
		
	}  
  
	public class throw_  
	{  
	    public static void main(String args[]) throws ArithmeticException,customException
	    {  
	        try  
	        {  
	            throw new customException(); 
	        }  
	        catch (customException e)  
	        {   
	            System.out.println("Exception "+e);  
	        }  
	  	        
	      finally
	      {
	        System.out.println("End of the code");  
	      }
	    } 
	    
	}
	

