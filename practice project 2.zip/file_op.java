package proj;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class file_op {
	public static void main(String[] args) {
	    try {
	      File f = new File("E:fileop.txt");
	      if (f.createNewFile()) {
	        System.out.println(f.getName() +"File is created : " ); } 
	      else {
	        System.out.println("File already exists."); }
	   
	      String append="hello world";
	      System.out.println("\nAppending : "+append);
			FileWriter ap = new FileWriter("E:fileop.txt",true);
	         ap.write(append);
	         ap.close();
	        
	          FileReader texts = new FileReader("E:fileop.txt");
	          System.out.print("\nReading the file :\n");
	          int i;
	          while (( i = texts.read()) != -1)
	          	System.out.print((char)i);
	          texts.close();
          
          File df = new File("E:fileop.txt");
          if (df.delete()) {
              System.out.println("\n\n"+df.getName() + "File is deleted!");
          }

          
	      
	    }
	       
	    catch (IOException e) {
	      System.out.println("An error occurred.");
	      e.printStackTrace();
	    }
	  }
}
