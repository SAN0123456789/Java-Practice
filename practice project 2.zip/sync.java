package proj;

class value{  
	 synchronized void print(int n){
	   for(int i=1;i<=5;i++){  
	     System.out.println(n*i);  
	     try{  
	      Thread.sleep(1000);  
	     }catch(Exception e)
	        {System.out.println(e);}  
	   }  	  
	 }  
	}  
	  
	class Thread1 extends Thread{  
	value t;  
	Thread1(value t){  
	this.t=t;  
	}  
	public void run(){  
	t.print(10);  
	}  
	  
	}  
	class Thread2 extends Thread{  
	value t;  
	Thread2(value t){  
	this.t=t;  
	}  
	public void run(){  
	t.print(100);  
	}  
	}  
	  
	public class sync{  
	public static void main(String args[]){  
	value val = new value(); 
	Thread1 t1=new Thread1(val);  
	Thread2 t2=new Thread2(val);  
	t1.start();  
	t2.start();  
	}  
	}  

	
	
	