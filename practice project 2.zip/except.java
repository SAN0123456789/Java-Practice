package proj;

class except {
	  public static void main(String[] args) {
	    try {

	    	int a[]=new int[5];  
	    	a[7]=10;
	    }

	    catch (Exception e) {
	      System.out.println("Exception - "+e);
	    }
	    
	    finally {
	      System.out.println("Finally block");
	    }
	  }
	}

