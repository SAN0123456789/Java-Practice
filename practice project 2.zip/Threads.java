package proj;

	class Threading {		
		class Threadrun extends Thread{
		   public void run(){
		      System.out.println("Thread running by Thread class");
		   }
		}
		class running implements Runnable{
			   public void run(){
			      System.out.println("Thread running by Runnable interface");
		      			      
			}			   
		}
	}
		   
		 public class Threads {
		   public static void main(String args[])
		   {
			   Threading runn = new Threading();
			   Threading.Threadrun t1 = runn.new Threadrun();
		       t1.start();
		      
			   Threading.running t2 = runn.new running();
			   Thread t= new Thread(t2);
		       t.start();
		   }
		}
	

