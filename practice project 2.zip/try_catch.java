package proj;

public class try_catch {  	  
    public static void main(String[] args) {  
        try  
        {  
        int i=10/0;   
        }  
     
        catch( Exception e)  
        {  
            System.out.println("Cannot Divide by 0 \n"+ e );  
        }  
    }  
      
}  
