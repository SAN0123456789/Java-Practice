package proj;

public class wait_sleep {

		private static Object o = new Object();	
		public static void main(String[] args) throws InterruptedException
		{
			System.out.println("Thread is sleeping");
			Thread.sleep(1000);
			System.out.println("Thread woke up after 1 second");
			
			synchronized(o)
			{
				System.out.println("Thread will wait for timeout");
				o.wait(1000);
			}
			
			System.out.println("Thread woke up after timeout");
		}
	}

