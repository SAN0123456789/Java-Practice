package proj;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException; 

public class files {
	public static void main(String[] args) {
		
		try 
		{	
			String text="Hello ";
			FileWriter f = new FileWriter("E:file.txt");
            f.write(text);
            f.close();
            
            FileReader texts = new FileReader("E:file.txt");
            System.out.print("Reading the file after written :\n");
            int i;
            while (( i = texts.read()) != -1)
            	System.out.print((char)i);
            texts.close();
			         
			String append="hel";
			FileWriter ap = new FileWriter("E:file.txt",true);
            ap.write(append);
            ap.close();
            
            FileReader re = new FileReader("E:file.txt");
            System.out.print("\n\nReading the file after Appended :\n");
            int j;
            while (( j = re.read()) != -1)
            	System.out.print((char)j);
            re.close();
		}	
		
		catch(IOException e){	
			System.out.println("Error occured :");
			e.printStackTrace();			
		}
		}
}