package proj;

class Encapsulation_Student{  
	private String name;  
	public String getname(){  
		return name;  
	}  
	public void setname(String name){  
		this.name=name;  
	}  
	}

class Inheritance_Employee{  
	 int salary=20000;  
	}  
	class Manager extends Inheritance_Employee{  
	 int bonus=3000;  
	}
	
	abstract class Parent {
	    void override_Print()
	    { System.out.println("parent class");
	    }
	}
	 
	class subclass extends Parent {
	    void override_Print() 
	    { System.out.println("sub class"); 
	    }
	}	
	
public class oop_pillars {
	public static void main(String[] args) {
	Encapsulation_Student s = new Encapsulation_Student();  	
	s.setname("Ravi"); 	
	System.out.println(s.getname());  
	
	   Manager p=new Manager();  
	   System.out.println("Manager salary :"+p.salary);  
	   System.out.println("Manager bonus :"+p.bonus);
	   
       subclass a = new subclass();
       a.override_Print();
	}
}



