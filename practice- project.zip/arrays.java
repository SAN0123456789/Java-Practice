
package projects;
import java.util.Arrays; 
public class arrays {

	public static void main(String[] args) {
		String[] place= {"abc","a","box"};
		System.out.println(place.length);
		System.out.println(Arrays.toString(place));  
		
	}

}
