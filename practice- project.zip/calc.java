package projects;


class access {
		private int a = 10;
		protected void display() {
			System.out.println(" Mod class");
		}		
}

class calc extends access {
    public static void main(String[] args) {
    
        access disp = new access();
        System.out.println(" Mod class");
        disp.display();
    }
}

