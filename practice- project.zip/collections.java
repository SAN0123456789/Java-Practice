package projects;

import java.util.*;
public class collections {

		    public static void main(String[] args){
		        ArrayList<String> text = new ArrayList<>();
		        // Add elements
		        text.add("abc");
		        text.add("hand");
		        text.add("car");
		        text.remove("abc");

		        System.out.println("ArrayList: " + text);
		    }
		}
	
