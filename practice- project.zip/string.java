package projects;


public class string{  
    public static void main(String[] args){  
        StringBuffer buffer=new StringBuffer("STRING ");  
        buffer.append("BUFFER");  
        System.out.println(buffer);  
    
        StringBuilder builder=new StringBuilder("STRING ");  
        builder.append("BUILDER");  
        System.out.println(builder);  
    } 
}  

