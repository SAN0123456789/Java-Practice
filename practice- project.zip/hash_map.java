package projects;
import java.util.HashMap;
public class hash_map {

	  public static void main(String[] args) {

	    HashMap<String, String> Cities = new HashMap<String, String>();

	    Cities.put("a", "Delhi");
	    Cities.put("b", "Chennai");
	    Cities.put("c", "Jaipur");
	    System.out.println(Cities);
	    System.out.println(Cities.get("b"));	    
	    Cities.remove("c");
	    System.out.println(Cities);
	  }
	}
	

