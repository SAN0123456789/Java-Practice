package projects;

public class constructor {
	
	constructor()
	{System.out.println("Constructor");
	
	} 
	
	
	public static void main(String[] args) {

			constructor c = new constructor();  
			}  
		}  

