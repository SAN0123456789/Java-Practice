package projects;


class outerclass {
	  int x = 8;

	  class innerclass {
	    int y = 4;
	  }
	}

public class class_inner {
	  public static void main(String[] args) {
	    outerclass Outer = new outerclass();
	    outerclass.innerclass Inner = Outer.new innerclass();
	    System.out.println(Inner.y + Outer.x);
	  }
	}
