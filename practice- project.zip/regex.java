package projects;
import java.util.regex.*;  




public class regex{  
public static void main(String args[]){  
//1st way  
Pattern p = Pattern.compile(".b");//. represents single character  
Matcher m = p.matcher("abc");  
boolean match = m.find();
if(match) {
  System.out.println("Match found");

}

}
}