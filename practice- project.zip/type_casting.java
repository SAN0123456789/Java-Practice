package hello;

public class type_casting {

	public static void main(String[] args) {
		// widening type casting
		int x=5;
		float y=x;
		System.out.println("Before conversion "+x);
		System.out.println("After conversion "+y);

		// Narrowing Type casting
		double a = 10.523 ;
		int b = (int) a ;
		System.out.println("Before conversion "+a);
		System.out.println("After conversion "+b);
	}
	
}



