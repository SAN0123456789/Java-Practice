package projects;

public class call {

			  static void callMethod() {
			    System.out.println("Method called");
			  }

			  public static void main(String[] args) {
			    callMethod();
			  }
			
}


